# ctfd-template

1. 문제 파일 작성
2. `ctf challenge add [PATH]`
3. `ctf challenge install [PATH]`

-> 파일 내용 수정한 경우
`ctf challenge sync [PATH]`